// backend/src/routes/appointments.ts
import express from "express";
import pool from "../db";
import { requireAuth, AuthRequest } from "../middleware/auth";

const router = express.Router();

/**
 * POST /api/appointments
 * Minimál létrehozás üres rács kattintásból.
 * Elvárt mezők: employee_id, start_time, end_time
 * Opcionális: title, client_id, client_name, location_id
 */
router.post("/", requireAuth, async (req: AuthRequest, res) => {
  const { employee_id, start_time, end_time, title, client_id, client_name, location_id } = req.body || {};
  if (!employee_id || !start_time || !end_time) {
    return res.status(400).json({ error: "employee_id, start_time, end_time kötelező" });
  }

  try {
    // ha van clients tábla és client_id nincs, akkor client_name alapján nem hozunk létre automatán (később lehet).
    const r = await pool.query(
      `INSERT INTO appointments (employee_id, client_id, location_id, title, start_time, end_time, status, notes)
       VALUES ($1::uuid, $2::uuid, $3::uuid, $4::text, $5::timestamptz, $6::timestamptz, COALESCE($7::text,'confirmed'), COALESCE($8::text,''))
       RETURNING id`,
      [employee_id, client_id || null, location_id || null, title || (client_name ? `Foglalás - ${client_name}` : "Foglalás"), start_time, end_time, "confirmed", ""]
    );
    return res.status(201).json({ id: r.rows[0].id });
  } catch (err: any) {
    console.error("[POST /api/appointments] error:", err);
    return res.status(500).json({ error: "Nem sikerült létrehozni", detail: err?.message || String(err), code: err?.code || null });
  }
});

/**
 * GET /api/appointments/:id/detail
 * Drawer adatok. (ha már nálatok létezik más endpoint, ezt a front felől át lehet állítani)
 */
router.get("/:id/detail", requireAuth, async (req: AuthRequest, res) => {
  const { id } = req.params;
  try {
    const ap = await pool.query(
      `SELECT a.*, 
              COALESCE(c.full_name, c.name, '') AS client_name
       FROM appointments a
       LEFT JOIN clients c ON c.id = a.client_id
       WHERE a.id = $1::uuid`,
      [id]
    );
    if (ap.rowCount === 0) return res.status(404).json({ error: "Nincs ilyen időpont" });

    // services/product list safe (ha nincs tábla, üres)
    const hasServices = (await pool.query(`SELECT to_regclass('public.appointment_services') IS NOT NULL AS ok`)).rows[0].ok;
    const services = hasServices
      ? (await pool.query(
          `SELECT aps.id, aps.service_id, COALESCE(s.name,'') AS name, aps.duration_min, aps.price, aps.sort_order
           FROM appointment_services aps
           LEFT JOIN services s ON s.id = aps.service_id
           WHERE aps.appointment_id = $1::uuid
           ORDER BY aps.sort_order, aps.created_at`,
          [id]
        )).rows
      : [];

    return res.json({ appointment: ap.rows[0], services });
  } catch (err: any) {
    console.error("[GET /api/appointments/:id/detail] error:", err);
    return res.status(500).json({ error: "Nem sikerült betölteni", detail: err?.message || String(err), code: err?.code || null });
  }
});

/**
 * PATCH /api/appointments/:id
 * Move/resize + drawer mezők mentése (status/notes/payment + start/end).
 */
router.patch("/:id", requireAuth, async (req: AuthRequest, res) => {
  const { id } = req.params;
  const {
    start_time,
    end_time,
    employee_id,
    location_id,
    title,
    status,
    notes,
    payment_status,
    paid_total,
    discount_percent,
  } = req.body || {};

  try {
    const fields: string[] = [];
    const params: any[] = [];
    let i = 1;

    const add = (field: string, value: any, cast?: string) => {
      if (value === undefined) return;
      params.push(value);
      fields.push(`${field} = $${i}${cast ? `::${cast}` : ""}`);
      i += 1;
    };

    add("start_time", start_time, "timestamptz");
    add("end_time", end_time, "timestamptz");
    add("employee_id", employee_id, "uuid");
    add("location_id", location_id, "uuid");
    add("title", title, "text");
    add("status", status, "text");
    add("notes", notes, "text");

    // opcionális mezők (ha léteznek a táblában)
    const cols = await pool.query(
      `SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name='appointments'`
    );
    const colset = new Set(cols.rows.map((x: any) => x.column_name));
    if (colset.has("payment_status")) add("payment_status", payment_status, "text");
    if (colset.has("paid_total")) add("paid_total", paid_total, "numeric");
    if (colset.has("discount_percent")) add("discount_percent", discount_percent, "numeric");
    if (colset.has("updated_at")) add("updated_at", new Date().toISOString(), "timestamptz");

    if (!fields.length) return res.json({ ok: true });

    params.push(id);
    const q = `UPDATE appointments SET ${fields.join(", ")} WHERE id = $${i}::uuid RETURNING id`;
    const r = await pool.query(q, params);
    return res.json({ ok: true, id: r.rows[0]?.id });
  } catch (err: any) {
    console.error("[PATCH /api/appointments/:id] error:", err);
    return res.status(500).json({ error: "Nem sikerült menteni", detail: err?.message || String(err), code: err?.code || null });
  }
});

export default router;
