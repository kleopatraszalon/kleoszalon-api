import express from "express";
import jwt from "jsonwebtoken";
import pool from "../db";

const router = express.Router();

function getUserRole(req: express.Request): string {
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : null;
  const secret = process.env.JWT_SECRET;
  if (!token || !secret) return "all";
  try {
    const payload: any = jwt.verify(token, secret);
    return String(payload?.role || "all").toLowerCase();
  } catch {
    return "all";
  }
}

router.get("/", async (req, res) => {
  const userRole = getUserRole(req);

  const sql = `
    SELECT
      id,
      COALESCE(NULLIF(label_hu, ''), NULLIF(name, ''), route, 'Névtelen') AS name,
      icon,
      route,
      order_index,
      parent_id,
      LOWER(COALESCE(NULLIF(required_role, ''), 'all')) AS required_role
    FROM public.menus
    WHERE LOWER(COALESCE(NULLIF(required_role, ''), 'all')) IN ('all', $1)
    ORDER BY COALESCE(parent_id, 0), order_index, id
  `;

  try {
    const { rows } = await pool.query(sql, [userRole]);

    const byId = new Map<number, any>();
    rows.forEach((r: any) => {
      byId.set(r.id, {
        id: r.id,
        name: r.name,
        icon: r.icon ?? null,
        route: r.route ?? null,
        order_index: r.order_index ?? 0,
        parent_id: r.parent_id ?? null,
        required_role: r.required_role,
        submenus: [],
      });
    });

    const roots: any[] = [];
    rows.forEach((r: any) => {
      const item = byId.get(r.id);
      if (r.parent_id && byId.has(r.parent_id)) {
        byId.get(r.parent_id).submenus.push(item);
      } else {
        roots.push(item);
      }
    });

    const sortTree = (items: any[]) => {
      items.sort((a, b) => (a.order_index ?? 0) - (b.order_index ?? 0) || a.id - b.id);
      items.forEach((node) => sortTree(node.submenus || []));
    };
    sortTree(roots);

    return res.json(roots);
  } catch (err: any) {
    console.error("❌ Menü betöltési hiba:", err?.message || err);
    return res.status(500).json({ error: "Adatbázis hiba a menü lekérésekor" });
  }
});

export default router;
