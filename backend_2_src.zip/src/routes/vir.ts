import { Router, Response } from "express";
import pool from "../db";
import { AuthRequest, requireAuth } from "../middleware/auth";

const router = Router();

type VirQueryParams = {
  from?: string;
  to?: string;
  locationId?: string;
  limit?: string;
};

function parseDateInput(value: string | undefined, fallback: string): string {
  if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return fallback;
  return value;
}

function parseLimit(value: string | undefined, fallback = 10, max = 100): number {
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return fallback;
  return Math.min(Math.floor(n), max);
}

function toErrorMessage(error: unknown): string {
  if (error instanceof Error) return error.message;
  return "unknown_error";
}

function getScopedLocationId(req: AuthRequest): string | null {
  const query = (req.query || {}) as VirQueryParams;
  const requestedLocationId = query.locationId || null;

  if ((req.user?.role || "").toLowerCase() === "admin") {
    return requestedLocationId;
  }

  const userLocationId =
    req.user?.location_id !== undefined && req.user?.location_id !== null
      ? String(req.user.location_id)
      : null;

  return userLocationId || requestedLocationId || null;
}


router.get("/overview", requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const query = (req.query || {}) as VirQueryParams;
    const today = new Date();
    const defaultTo = today.toISOString().slice(0, 10);
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().slice(0, 10);

    const from = parseDateInput(query.from, monthStart);
    const to = parseDateInput(query.to, defaultTo);
    const locationId = getScopedLocationId(req);

    const summaryPromise = pool.query(
      `SELECT * FROM public.vir_dashboard_summary($1::date, $2::date, $3::uuid)`,
      [from, to, locationId]
    );

    const revenueSeriesPromise = pool.query(
      `SELECT * FROM public.vir_revenue_series($1::date, $2::date, $3::uuid) ORDER BY day`,
      [from, to, locationId]
    );

    const salesBreakdownPromise = pool.query(
      `SELECT
         COALESCE(SUM(CASE WHEN LOWER(COALESCE(woi.item_type, '')) = 'service' THEN COALESCE(woi.line_total, 0) ELSE 0 END), 0)::numeric(14,2) AS services_total,
         COALESCE(SUM(CASE WHEN LOWER(COALESCE(woi.item_type, '')) = 'product' THEN COALESCE(woi.line_total, 0) ELSE 0 END), 0)::numeric(14,2) AS products_total,
         COUNT(*) FILTER (WHERE LOWER(COALESCE(woi.item_type, '')) = 'product')::integer AS sold_products_count
       FROM public.work_order_items woi
       JOIN public.work_orders wo ON wo.id = woi.work_order_id
       WHERE wo.created_at::date BETWEEN $1::date AND $2::date
         AND ($3::uuid IS NULL OR wo.location_id = $3::uuid)`,
      [from, to, locationId]
    );

    const visitsPromise = pool.query(
      `SELECT
         COUNT(DISTINCT a.client_id)::integer AS clients_count,
         COUNT(*)::integer AS appointments_total,
         COUNT(*) FILTER (WHERE a.client_id IS NOT NULL AND EXISTS (
           SELECT 1
           FROM public.appointments prev
           WHERE prev.client_id = a.client_id
             AND prev.id <> a.id
             AND prev.start_time < a.start_time
             AND prev.status IN ('booked','confirmed','completed')
         ))::integer AS returning_appointments,
         COUNT(*) FILTER (WHERE a.client_id IS NOT NULL AND NOT EXISTS (
           SELECT 1
           FROM public.appointments prev
           WHERE prev.client_id = a.client_id
             AND prev.id <> a.id
             AND prev.start_time < a.start_time
             AND prev.status IN ('booked','confirmed','completed')
         ))::integer AS new_appointments
       FROM public.appointments a
       WHERE a.start_time::date BETWEEN $1::date AND $2::date
         AND ($3::uuid IS NULL OR a.location_id = $3::uuid)`,
      [from, to, locationId]
    );

    const occupancyPromise = pool.query(
      `WITH period AS (
         SELECT $1::date AS from_day, $2::date AS to_day
       ),
       employee_count AS (
         SELECT COUNT(*)::numeric AS cnt
         FROM public.employees e
         WHERE e.active IS DISTINCT FROM false
           AND ($3::uuid IS NULL OR e.location_id = $3::uuid)
       ),
       daily_slots AS (
         SELECT GREATEST((SELECT cnt FROM employee_count), 1) * ((period.to_day - period.from_day) + 1) * 32 AS total_slots
         FROM period
       )
       SELECT
         COUNT(*) FILTER (WHERE a.status IN ('booked','confirmed','completed'))::integer AS booked_slots,
         COUNT(*) FILTER (WHERE a.status = 'completed')::integer AS completed_slots,
         COUNT(*) FILTER (WHERE a.status IN ('cancelled','no_show'))::integer AS lost_slots,
         ROUND((COUNT(*) FILTER (WHERE a.status IN ('booked','confirmed','completed'))::numeric / NULLIF((SELECT total_slots FROM daily_slots), 0)) * 100, 2) AS occupancy_percent,
         ROUND((COUNT(*) FILTER (WHERE a.status = 'completed')::numeric / NULLIF((SELECT total_slots FROM daily_slots), 0)) * 100, 2) AS completion_percent,
         ROUND((COUNT(*) FILTER (WHERE a.status IN ('cancelled','no_show'))::numeric / NULLIF((SELECT total_slots FROM daily_slots), 0)) * 100, 2) AS lost_percent
       FROM public.appointments a
       WHERE a.start_time::date BETWEEN $1::date AND $2::date
         AND ($3::uuid IS NULL OR a.location_id = $3::uuid)`,
      [from, to, locationId]
    );

    const [summaryResult, revenueSeriesResult, salesBreakdownResult, visitsResult, occupancyResult] = await Promise.all([
      summaryPromise,
      revenueSeriesPromise,
      salesBreakdownPromise,
      visitsPromise,
      occupancyPromise,
    ]);

    const summary = summaryResult.rows[0] || {};
    const salesBreakdown = salesBreakdownResult.rows[0] || {};
    const visits = visitsResult.rows[0] || {};
    const occupancy = occupancyResult.rows[0] || {};

    return res.json({
      ok: true,
      summary: {
        revenue_total: Number(summary.revenue_total || 0),
        paid_total: Number(summary.paid_total || 0),
        appointments_count: Number(summary.appointments_count || 0),
        completed_count: Number(summary.completed_count || 0),
        cancelled_count: Number(summary.cancelled_count || 0),
        no_show_count: Number(summary.no_show_count || 0),
        avg_basket: Number(summary.avg_basket || 0),
        cancellation_rate_percent: Number(summary.cancellation_rate_percent || 0),
        no_show_rate_percent: Number(summary.no_show_rate_percent || 0),
      },
      sales_breakdown: {
        services_total: Number(salesBreakdown.services_total || 0),
        products_total: Number(salesBreakdown.products_total || 0),
        sold_products_count: Number(salesBreakdown.sold_products_count || 0),
      },
      visits: {
        clients_count: Number(visits.clients_count || 0),
        appointments_total: Number(visits.appointments_total || 0),
        new_appointments: Number(visits.new_appointments || 0),
        returning_appointments: Number(visits.returning_appointments || 0),
      },
      occupancy: {
        booked_slots: Number(occupancy.booked_slots || 0),
        completed_slots: Number(occupancy.completed_slots || 0),
        lost_slots: Number(occupancy.lost_slots || 0),
        occupancy_percent: Number(occupancy.occupancy_percent || 0),
        completion_percent: Number(occupancy.completion_percent || 0),
        lost_percent: Number(occupancy.lost_percent || 0),
      },
      revenue_series: revenueSeriesResult.rows,
    });
  } catch (error) {
    return res.status(500).json({ ok: false, error: toErrorMessage(error) });
  }
});

router.get("/dashboard", requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const query = (req.query || {}) as VirQueryParams;
    const today = new Date();
    const defaultTo = today.toISOString().slice(0, 10);
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().slice(0, 10);

    const from = parseDateInput(query.from, monthStart);
    const to = parseDateInput(query.to, defaultTo);
    const locationId = getScopedLocationId(req);

    const { rows } = await pool.query(
      `SELECT * FROM public.vir_dashboard_summary($1::date, $2::date, $3::uuid)`,
      [from, to, locationId]
    );

    return res.json({
      ok: true,
      summary: rows[0] || {
        revenue_total: 0,
        paid_total: 0,
        appointments_count: 0,
        completed_count: 0,
        cancelled_count: 0,
        no_show_count: 0,
        avg_basket: 0,
        cancellation_rate_percent: 0,
        no_show_rate_percent: 0,
      },
    });
  } catch (error) {
    return res.status(500).json({ ok: false, error: toErrorMessage(error) });
  }
});

router.get("/revenue-series", requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const query = (req.query || {}) as VirQueryParams;
    const today = new Date();
    const defaultTo = today.toISOString().slice(0, 10);
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().slice(0, 10);

    const from = parseDateInput(query.from, monthStart);
    const to = parseDateInput(query.to, defaultTo);
    const locationId = getScopedLocationId(req);

    const { rows } = await pool.query(
      `SELECT * FROM public.vir_revenue_series($1::date, $2::date, $3::uuid) ORDER BY day`,
      [from, to, locationId]
    );
    return res.json({ ok: true, rows });
  } catch (error) {
    return res.status(500).json({ ok: false, error: toErrorMessage(error) });
  }
});

router.get("/top-services", requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const query = (req.query || {}) as VirQueryParams;
    const limit = parseLimit(query.limit, 10, 50);
    const { rows } = await pool.query(`SELECT * FROM public.vir_top_services($1::integer)`, [limit]);
    return res.json({ ok: true, rows });
  } catch (error) {
    return res.status(500).json({ ok: false, error: toErrorMessage(error) });
  }
});

router.get("/top-staff", requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const query = (req.query || {}) as VirQueryParams;
    const limit = parseLimit(query.limit, 10, 50);
    const { rows } = await pool.query(`SELECT * FROM public.vir_top_staff($1::integer)`, [limit]);
    return res.json({ ok: true, rows });
  } catch (error) {
    return res.status(500).json({ ok: false, error: toErrorMessage(error) });
  }
});

router.get("/source-performance", requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const locationId = getScopedLocationId(req);
    const { rows } = await pool.query(
      `SELECT source_channel, location_id, appointments_count, completed_count, cancelled_count, no_show_count, revenue_total, paid_total
       FROM public.vw_vir_source_performance
       WHERE ($1::uuid IS NULL OR location_id = $1::uuid)
       ORDER BY revenue_total DESC NULLS LAST, appointments_count DESC`,
      [locationId]
    );
    return res.json({ ok: true, rows });
  } catch (error) {
    return res.status(500).json({ ok: false, error: toErrorMessage(error) });
  }
});

router.get("/cancellation-stats", requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const query = (req.query || {}) as VirQueryParams;
    const today = new Date();
    const defaultTo = today.toISOString().slice(0, 10);
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().slice(0, 10);

    const from = parseDateInput(query.from, monthStart);
    const to = parseDateInput(query.to, defaultTo);
    const locationId = getScopedLocationId(req);

    const { rows } = await pool.query(
      `SELECT day, location_id, total_appointments, cancelled_count, no_show_count, cancellation_rate_percent, no_show_rate_percent
       FROM public.vw_vir_cancellation_stats
       WHERE day BETWEEN $1::date AND $2::date
         AND ($3::uuid IS NULL OR location_id = $3::uuid)
       ORDER BY day`,
      [from, to, locationId]
    );
    return res.json({ ok: true, rows });
  } catch (error) {
    return res.status(500).json({ ok: false, error: toErrorMessage(error) });
  }
});

router.get("/kiosk-conversion", requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const query = (req.query || {}) as VirQueryParams;
    const today = new Date();
    const defaultTo = today.toISOString().slice(0, 10);
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().slice(0, 10);

    const from = parseDateInput(query.from, monthStart);
    const to = parseDateInput(query.to, defaultTo);
    const locationId = getScopedLocationId(req);

    const { rows } = await pool.query(
      `SELECT day, location_id, kiosk_appointments, kiosk_completed, kiosk_revenue
       FROM public.vw_vir_kiosk_conversion
       WHERE day BETWEEN $1::date AND $2::date
         AND ($3::uuid IS NULL OR location_id = $3::uuid)
       ORDER BY day`,
      [from, to, locationId]
    );
    return res.json({ ok: true, rows });
  } catch (error) {
    return res.status(500).json({ ok: false, error: toErrorMessage(error) });
  }
});

router.get("/signage-impact", requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const locationId = getScopedLocationId(req);
    const { rows } = await pool.query(
      `SELECT deal_id, title, location_id, active_from, active_to, appointments_during_campaign, revenue_during_campaign
       FROM public.vw_vir_signage_campaign_impact
       WHERE ($1::uuid IS NULL OR location_id = $1::uuid OR location_id IS NULL)
       ORDER BY active_from DESC, revenue_during_campaign DESC NULLS LAST`,
      [locationId]
    );
    return res.json({ ok: true, rows });
  } catch (error) {
    return res.status(500).json({ ok: false, error: toErrorMessage(error) });
  }
});

export default router;
