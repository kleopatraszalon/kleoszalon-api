// src/routes/locations.ts
import { Router, Request, Response } from "express";
import pool from "../db";

const router = Router();


// ===========================================================
// 🌐 PUBLIC TELEPHELY LISTA (login előtt is hívható)
// GET /api/locations/public
// Válasz: { ok: true, locations: [...] }
// ===========================================================
router.get("/public", async (_req: Request, res: Response) => {
  try {
    const result = await pool.query(
      `
      SELECT
        id,
        name,
        address,
        city,
        phone,
        email,
        is_active
      FROM locations
      WHERE is_active = true
      ORDER BY city, name;
      `
    );

    return res.json({ ok: true, locations: result.rows });
  } catch (err) {
    console.error("❌ Szalon lekérési hiba (public):", err);
    return res.status(500).json({ ok: false, error: "Nem sikerült lekérni a szalonokat" });
  }
});

// ===========================================================
// 🏢 SZALONOK / TELEPHELYEK LEKÉRÉSE
// GET /api/locations  (ha a routert így kötöd be: app.use("/api/locations", router))
// ===========================================================
router.get("/", async (_req: Request, res: Response) => {
  try {
    const result = await pool.query(
      `
      SELECT
        id,
        name,
        address,
        city,
        phone,
        email,
        is_active
      FROM locations
      WHERE is_active = true
      ORDER BY city, name;
      `
    );

    return res.json(result.rows);
  } catch (err) {
    console.error("❌ Szalon lekérési hiba:", err);
    return res.status(500).json({ error: "Nem sikerült lekérni a szalonokat" });
  }
});

// ===========================================================
// ➕ ÚJ SZALON HOZZÁADÁSA
// POST /api/locations
// ===========================================================
router.post("/", async (req: Request, res: Response) => {
  const { name, address, city, phone, email } = (req.body ?? {}) as {
    name?: string;
    address?: string;
    city?: string;
    phone?: string;
    email?: string;
  };

  if (!name || !city) {
    return res.status(400).json({ error: "Név és város megadása kötelező" });
  }

  try {
    const result = await pool.query(
      `
      INSERT INTO locations (name, address, city, phone, email, is_active)
      VALUES ($1, $2, $3, $4, $5, true)
      RETURNING *;
      `,
      [name, address ?? null, city, phone ?? null, email ?? null]
    );

    return res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error("❌ Szalon hozzáadási hiba:", err);
    return res.status(500).json({ error: "Nem sikerült hozzáadni a szalont" });
  }
});

// ===========================================================
// ✏️ SZALON MÓDOSÍTÁS
// PUT /api/locations/:id
// ===========================================================
router.put("/:id", async (req: Request, res: Response) => {
  const { id } = req.params;

  const { name, address, city, phone, email, is_active } = (req.body ?? {}) as {
    name?: string;
    address?: string;
    city?: string;
    phone?: string;
    email?: string;
    is_active?: boolean;
  };

  try {
    const result = await pool.query(
      `
      UPDATE locations
      SET
        name = $1,
        address = $2,
        city = $3,
        phone = $4,
        email = $5,
        is_active = $6
      WHERE id = $7
      RETURNING *;
      `,
      [
        name ?? null,
        address ?? null,
        city ?? null,
        phone ?? null,
        email ?? null,
        typeof is_active === "boolean" ? is_active : true,
        id,
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Szalon nem található" });
    }

    return res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Szalon módosítási hiba:", err);
    return res.status(500).json({ error: "Nem sikerült módosítani a szalont" });
  }
});

export default router;
