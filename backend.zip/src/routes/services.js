"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
// src/routes/services.ts
var express_1 = require("express");
var db_1 = require("../db");
var jsonwebtoken_1 = require("jsonwebtoken");
var router = express_1.default.Router();
// ugyanaz az auth helper
function authenticate(req, res, next) {
    var auth = req.headers.authorization;
    if (!auth) {
        return res.status(401).json({ error: "Nincs token" });
    }
    try {
        var token = auth.split(" ")[1];
        var decoded = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET);
        req.user = {
            id: decoded.userId,
            role: decoded.role || "guest",
            location_id: decoded.location_id || null,
        };
        next();
    }
    catch (err) {
        return res.status(403).json({ error: "Érvénytelen token" });
    }
}
// GET /api/services
// Visszaadja kategóriánként
router.get("/", authenticate, function (_req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var result, bucket, _i, _a, row, cat, response, err_1;
    return __generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                _b.trys.push([0, 2, , 3]);
                return [4 /*yield*/, db_1.default.query("\n      SELECT\n        id,\n        name,\n        price,\n        duration_minutes,\n        category_name\n      FROM services\n      ORDER BY category_name, name;\n      ")];
            case 1:
                result = _b.sent();
                bucket = {};
                for (_i = 0, _a = result.rows; _i < _a.length; _i++) {
                    row = _a[_i];
                    cat = row.category_name || "Egyéb";
                    if (!bucket[cat])
                        bucket[cat] = [];
                    bucket[cat].push({
                        id: row.id,
                        name: row.name,
                        price: Number(row.price) || 0,
                        duration_minutes: row.duration_minutes || 0,
                    });
                }
                response = Object.entries(bucket).map(function (_a) {
                    var category = _a[0], services = _a[1];
                    return ({
                        category: category,
                        services: services,
                    });
                });
                res.json(response);
                return [3 /*break*/, 3];
            case 2:
                err_1 = _b.sent();
                console.error("❌ Szolgáltatások lekérése hiba:", err_1);
                res.status(500).json({ error: "Szolgáltatások betöltése sikertelen" });
                return [3 /*break*/, 3];
            case 3: return [2 /*return*/];
        }
    });
}); });
exports.default = router;
